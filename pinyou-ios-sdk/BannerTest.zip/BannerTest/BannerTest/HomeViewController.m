//
//  HomeViewController.m
//  BannerTest
//
//  Created by lide on 14-3-19.
//  Copyright (c) 2014年 lide. All rights reserved.
//

#import "HomeViewController.h"
#import "Pinyou.h"
#import "PYBannerView.h"
#import "PYBannerViewDelegate.h"

@interface HomeViewController () <PYBannerViewDelegate>

@end

@implementation HomeViewController

- (void)clickButton1:(id)sender
{
//    [Pinyou showDefaultTopBannerView];
    
    PYBannerView *bannerView = [[[PYBannerView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)] autorelease];
    bannerView.delegate = self;
    [bannerView setAdUnitId:@"hA.3Y"];
    
    bannerView.frame = CGRectMake(0, [(UINavigationController *)self.navigationController navigationBar].frame.origin.y + [(UINavigationController *)self.navigationController navigationBar].frame.size.height, 320, 50);
    
    [[(UINavigationController *)self.navigationController visibleViewController].view addSubview:bannerView];
    
    [bannerView loadAdInfo];
}

- (void)clickButton2:(id)sender
{
    [Pinyou showDefaultMiddleBannerView];
}

- (void)clickButton3:(id)sender
{
    [Pinyou showDefaultBottomBannerView];
}

- (void)clickRight:(id)sender
{
    UITabBarController *tabBarVC = [[UITabBarController alloc] init];
    HomeViewController *vc1 = [[HomeViewController alloc] init];
    HomeViewController *vc2 = [[HomeViewController alloc] init];
    tabBarVC.viewControllers = [NSArray arrayWithObjects:vc1, vc2, nil];
    [self.navigationController pushViewController:tabBarVC animated:YES];
}

- (void)loadView
{
    [super loadView];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithTitle:@"Tab" style:UIBarButtonItemStyleBordered target:self action:@selector(clickRight:)];
    self.navigationItem.rightBarButtonItem = right;
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button1.frame = CGRectMake(100, 100, 120, 40);
    [button1 setTitle:@"Top" forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(clickButton1:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button2.frame = CGRectMake(100, 150, 120, 40);
    [button2 setTitle:@"Middle" forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(clickButton2:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    UIButton *button3 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button3.frame = CGRectMake(100, 200, 120, 40);
    [button3 setTitle:@"Bottom" forState:UIControlStateNormal];
    [button3 addTarget:self action:@selector(clickButton3:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button3];
}

//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
//{
//    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
//    if (self) {
//        // Custom initialization
//    }
//    return self;
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - PYBannerViewDelegate

- (void)bannerViewDidLoadImageData:(PYBannerView *)bannerView success:(PYBannerLoadSuccessBlock)successBlock
{
    bannerView.transform = CGAffineTransformMake(1, 0, 0, 1, 0, -(bannerView.frame.origin.y + bannerView.frame.size.height));
    [UIView animateWithDuration:0.35 animations:^{
        bannerView.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        successBlock();
    }];
}

- (void)bannerViewDidLoadHTMLData:(PYBannerView *)bannerView success:(PYBannerLoadSuccessBlock)successBlock
{
    bannerView.transform = CGAffineTransformMake(1, 0, 0, 1, 0, -(bannerView.frame.origin.y + bannerView.frame.size.height));
    [UIView animateWithDuration:0.35 animations:^{
        bannerView.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        successBlock();
    }];
}

- (void)bannerViewDidClickCloseButton:(PYBannerView *)bannerView finished:(PYBannerCloseBlock)closeBlock
{
    [UIView animateWithDuration:0.35 animations:^{
        bannerView.transform = CGAffineTransformMake(1, 0, 0, 1, 0, -(bannerView.frame.origin.y + bannerView.frame.size.height));
    } completion:^(BOOL finished) {
        closeBlock();
    }];
}

- (void)bannerViewDidLoadDataError:(PYBannerView *)bannerView error:(NSError *)error
{
    NSLog(@"error domain = %@, error code = %i, error description = %@", error.domain, (int)error.code, error.description);
}

@end
