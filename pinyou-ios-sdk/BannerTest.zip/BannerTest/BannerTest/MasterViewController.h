//
//  MasterViewController.h
//  BannerTest
//
//  Created by lide on 14-3-19.
//  Copyright (c) 2014年 lide. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;

@end
